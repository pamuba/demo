import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet';
import GreetClass from './components/GreetClass';
import Hello from './components/Hello';
import Message from './components/Message';
//JSX
function App() {
  return (
    <div className="App">
      <header className="App-header">
       {/* <Greet name="Bruce" character="Batman">
        <h3>Children Props</h3>
       </Greet>
       <Greet name="Clark" character="Superman"/>
       <Greet name="Diana" character="Wonder Woman"/> */}

       {/* <GreetClass name="Bruce" character="Batman">
       <h3>Children Props</h3>
       </GreetClass>
       <GreetClass name="Clark" character="Superman"/>
       <GreetClass name="Diana" character="Woder Woman"/> */}

       <Message></Message>
      </header>
    </div>
  );
}

export default App;
