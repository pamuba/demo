import React from 'react'

// export default function Greet() {
//   return (
//     <div>Greet</div>
//   )
// }

const Greet = props => {
    return (
        <>
            <h1>Hello {props.name} aka {props.character}</h1>
            {props.children}
        </>
    )
}

export default Greet