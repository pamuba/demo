import React, { Component } from 'react'

export class GreetClass extends Component {
  render() {
    return (
      <>
        <h1>
          Hello {this.props.name} aka {this.props.character}
        </h1>
        {this.props.children}
      </>
    )
  }
}

export default GreetClass