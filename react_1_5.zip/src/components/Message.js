import React, { Component } from 'react'

export class Message extends Component {
  constructor(){
    super()
    this.state = {
        message:"Hello World"
    }
  }
  changeMessage(){
    this.setState({
        message:"Hello World from New State"
    })
  }
  render() {
    return (
      <div>
        <h1>{this.state.message}</h1>
        <button onClick={()=>this.changeMessage()}>Display</button>
      </div>
    )
  }
}

export default Message